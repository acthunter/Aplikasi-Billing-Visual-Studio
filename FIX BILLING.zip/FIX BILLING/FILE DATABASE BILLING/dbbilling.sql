-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jan 2019 pada 02.33
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbilling`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbllogin`
--

CREATE TABLE `tbllogin` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `level` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbllogin`
--

INSERT INTO `tbllogin` (`username`, `password`, `level`) VALUES
('owner', 'owner', 'owner'),
('admin', 'admin', 'admin'),
('personal', 'personal', 'personal'),
('sonia', 'sonia', 'owner'),
('ari', 'ari', 'admin'),
('andre', 'andre', 'personal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblreguler`
--

CREATE TABLE `tblreguler` (
  `no` varchar(3) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `durasi` time NOT NULL,
  `tagihan` int(11) NOT NULL,
  `haritgl` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tblreguler`
--

INSERT INTO `tblreguler` (`no`, `nama`, `durasi`, `tagihan`, `haritgl`) VALUES
('1', 'Saya', '00:00:22', 1000, 'Rabu, 02 Januari 2019'),
('1', 'Kambing', '00:00:10', 500, 'Selasa, 08 Januari 2019'),
('1', 'Sayur Kol', '00:00:18', 1000, 'Jumat, 11 Januari 2019'),
('1', 'Thanos', '00:00:26', 1000, 'Rabu, 09 Januari 2019'),
('1', 'dsf', '00:00:04', 500, 'Rabu, 09 Januari 2019'),
('1', 'hfgh', '00:00:18', 1000, 'Rabu, 09 Januari 2019'),
('1', 'SAayaaaa', '00:00:02', 500, 'Rabu, 09 Januari 2019');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
