-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Jan 2019 pada 08.27
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbilling`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbllogin`
--

CREATE TABLE `tbllogin` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbllogin`
--

INSERT INTO `tbllogin` (`username`, `password`, `level`) VALUES
('owner', 'owner', 'owner'),
('admin', 'admin', 'admin'),
('user', 'user', 'user'),
('personal', 'personal', 'personal'),
('personal', 'personal', 'personal'),
('ari', 'ari', 'admin'),
('saya', 'saya', 'owner'),
('rizki', 'rizki', 'owner');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblreguler`
--

CREATE TABLE `tblreguler` (
  `No` varchar(2) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Durasi` varchar(15) NOT NULL,
  `Tagihan` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tblreguler`
--

INSERT INTO `tblreguler` (`No`, `Nama`, `Durasi`, `Tagihan`) VALUES
('', '', '', 0),
('1', 'ari', '0:0:23:9', 500),
('', '', '0:0:34:2', 500),
('1', '', '0:0:44:4', 500),
('1', 'alan', '0:0:11:2', 500);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
