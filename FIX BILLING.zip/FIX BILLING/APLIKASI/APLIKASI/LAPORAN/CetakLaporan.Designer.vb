﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CetakLaporan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CLFix = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.CRLaporan1 = New APLIKASI.CRLaporan()
        Me.SuspendLayout()
        '
        'CLFix
        '
        Me.CLFix.ActiveViewIndex = 0
        Me.CLFix.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CLFix.Cursor = System.Windows.Forms.Cursors.Default
        Me.CLFix.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CLFix.Location = New System.Drawing.Point(0, 0)
        Me.CLFix.Name = "CLFix"
        Me.CLFix.ReportSource = Me.CRLaporan1
        Me.CLFix.Size = New System.Drawing.Size(640, 364)
        Me.CLFix.TabIndex = 0
        '
        'CetakLaporan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(640, 364)
        Me.Controls.Add(Me.CLFix)
        Me.Name = "CetakLaporan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CetakLaporan"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CLFix As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents CRLaporan1 As APLIKASI.CRLaporan
End Class
