﻿Imports System.Data.OleDb
Imports MySql.Data.MySqlClient
Imports CrystalDecisions.CrystalReports.Engine
Module koneksi
    Public conn As MySqlConnection
    Public da As MySqlDataAdapter
    Public ds As DataSet
    Public cmd As MySqlCommand
    Public dt As DataTable
    Public rd As MySqlDataReader
    Public str, sql As String
    Public hasil As Integer
    Public database As New MySqlConnection
    Public tampil As New MySql.Data.MySqlClient.MySqlCommand
    Public tampilkan As MySql.Data.MySqlClient.MySqlDataReader
    Public cari As OleDbDataReader
    Public dml As OleDbCommand

    Public Sub Koneksi_Ok()

        Dim str As String = "server=localhost;user=root;Persist Security Info=True;database=dbbilling;Convert Zero Datetime=True"
        conn = New MySqlConnection(str)
        If conn.State = ConnectionState.Closed Then
            conn.Open()
            
        End If

    End Sub

    Sub Close()
        Throw New NotImplementedException
    End Sub

End Module
