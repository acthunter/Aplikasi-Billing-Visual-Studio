﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reguler
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txttagihan = New System.Windows.Forms.TextBox()
        Me.txtdurasi = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cno = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtdetik = New System.Windows.Forms.Label()
        Me.txtmenit = New System.Windows.Forms.Label()
        Me.txtjam = New System.Windows.Forms.Label()
        Me.txtmilidetik = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.DWaktu = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(30, 299)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(119, 30)
        Me.Button6.TabIndex = 35
        Me.Button6.Text = "BERSIH"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(30, 225)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(245, 28)
        Me.Button2.TabIndex = 31
        Me.Button2.Text = "STOP"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(30, 164)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(245, 30)
        Me.Button1.TabIndex = 30
        Me.Button1.Text = "START"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txttagihan
        '
        Me.txttagihan.Enabled = False
        Me.txttagihan.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttagihan.Location = New System.Drawing.Point(107, 259)
        Me.txttagihan.Name = "txttagihan"
        Me.txttagihan.ReadOnly = True
        Me.txttagihan.Size = New System.Drawing.Size(168, 23)
        Me.txttagihan.TabIndex = 29
        Me.txttagihan.Text = "0"
        '
        'txtdurasi
        '
        Me.txtdurasi.Enabled = False
        Me.txtdurasi.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdurasi.Location = New System.Drawing.Point(107, 197)
        Me.txtdurasi.Name = "txtdurasi"
        Me.txtdurasi.ReadOnly = True
        Me.txtdurasi.Size = New System.Drawing.Size(168, 23)
        Me.txtdurasi.TabIndex = 28
        '
        'txtnama
        '
        Me.txtnama.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnama.Location = New System.Drawing.Point(107, 132)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(168, 23)
        Me.txtnama.TabIndex = 27
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(27, 262)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 15)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Tagihan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(27, 197)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 15)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Durasi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 132)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 15)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(27, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 15)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "No Bilik"
        '
        'Timer1
        '
        '
        'cno
        '
        Me.cno.Enabled = False
        Me.cno.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.FormattingEnabled = True
        Me.cno.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.cno.Location = New System.Drawing.Point(107, 106)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(42, 23)
        Me.cno.TabIndex = 44
        Me.cno.Text = "1"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Lucida Bright", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(196, 17)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(484, 42)
        Me.Label12.TabIndex = 64
        Me.Label12.Text = "INFORMASI PEMAKAIAN"
        '
        'txtdetik
        '
        Me.txtdetik.AutoSize = True
        Me.txtdetik.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdetik.Location = New System.Drawing.Point(618, 225)
        Me.txtdetik.Name = "txtdetik"
        Me.txtdetik.Size = New System.Drawing.Size(33, 32)
        Me.txtdetik.TabIndex = 42
        Me.txtdetik.Text = "0"
        '
        'txtmenit
        '
        Me.txtmenit.AutoSize = True
        Me.txtmenit.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmenit.Location = New System.Drawing.Point(618, 176)
        Me.txtmenit.Name = "txtmenit"
        Me.txtmenit.Size = New System.Drawing.Size(33, 32)
        Me.txtmenit.TabIndex = 41
        Me.txtmenit.Text = "0"
        '
        'txtjam
        '
        Me.txtjam.AutoSize = True
        Me.txtjam.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtjam.Location = New System.Drawing.Point(618, 131)
        Me.txtjam.Name = "txtjam"
        Me.txtjam.Size = New System.Drawing.Size(33, 32)
        Me.txtjam.TabIndex = 40
        Me.txtjam.Text = "0"
        '
        'txtmilidetik
        '
        Me.txtmilidetik.AutoSize = True
        Me.txtmilidetik.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmilidetik.Location = New System.Drawing.Point(665, 237)
        Me.txtmilidetik.Name = "txtmilidetik"
        Me.txtmilidetik.Size = New System.Drawing.Size(15, 15)
        Me.txtmilidetik.TabIndex = 43
        Me.txtmilidetik.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(701, 131)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(73, 32)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "JAM"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(701, 176)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(109, 32)
        Me.Label9.TabIndex = 49
        Me.Label9.Text = "MENIT"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Perpetua Titling MT", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(701, 225)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 32)
        Me.Label10.TabIndex = 50
        Me.Label10.Text = "DETIK"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.MintCream
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Location = New System.Drawing.Point(-2, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(892, 71)
        Me.Panel1.TabIndex = 48
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(155, 299)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(120, 30)
        Me.Button3.TabIndex = 65
        Me.Button3.Text = "KELUAR"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'DWaktu
        '
        Me.DWaktu.Location = New System.Drawing.Point(624, 101)
        Me.DWaktu.Name = "DWaktu"
        Me.DWaktu.Size = New System.Drawing.Size(200, 20)
        Me.DWaktu.TabIndex = 66
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(348, 172)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(197, 15)
        Me.Label5.TabIndex = 67
        Me.Label5.Text = "0 Detik   - 15 Detik = Rp 500 "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(348, 197)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(201, 15)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "15 Detik - 59 Detik = Rp 1000"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(348, 225)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(201, 15)
        Me.Label7.TabIndex = 69
        Me.Label7.Text = "1 Menit  - 1 Jam      = Rp 5000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Lucida Bright", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(430, 148)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 15)
        Me.Label11.TabIndex = 70
        Me.Label11.Text = "Tarif"
        '
        'reguler
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.ClientSize = New System.Drawing.Size(888, 341)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.DWaktu)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.txtmilidetik)
        Me.Controls.Add(Me.txtjam)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtmenit)
        Me.Controls.Add(Me.txttagihan)
        Me.Controls.Add(Me.txtdurasi)
        Me.Controls.Add(Me.txtdetik)
        Me.Controls.Add(Me.txtnama)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "reguler"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "INFORMASI PEMAKAIAN"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txttagihan As System.Windows.Forms.TextBox
    Friend WithEvents txtdurasi As System.Windows.Forms.TextBox
    Friend WithEvents txtnama As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents cno As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtdetik As System.Windows.Forms.Label
    Friend WithEvents txtmenit As System.Windows.Forms.Label
    Friend WithEvents txtjam As System.Windows.Forms.Label
    Friend WithEvents txtmilidetik As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents DWaktu As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
