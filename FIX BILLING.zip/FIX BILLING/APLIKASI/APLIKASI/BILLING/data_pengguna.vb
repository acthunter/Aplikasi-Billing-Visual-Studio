﻿Imports MySql.Data.MySqlClient
Public Class data_pengguna
    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tbllogin", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tbllogin")
        tabellogin.DataSource = (ds.Tables("tbllogin"))

    End Sub

    Private Sub data_admin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Koneksi_Ok()
        Call tampil()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            sql = "INSERT INTO tbllogin VALUES('" & txtuser.Text & "', '" & txtpass.Text & "', '" & clevel.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim hapus As String
        hapus = "delete from tbllogin where username='" & txtuser.Text & "'"
        cmd = New MySqlCommand(hapus, conn)
        cmd.ExecuteNonQuery()
        MsgBox("DATA SUDAH TERHAPUS", MsgBoxStyle.Information, "INFORMASI")
        txtuser.Enabled = True
        Call tampil()

    End Sub


    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        txtuser.Text = ""
        txtpass.Text = ""
        clevel.Text = ""
    End Sub

    Private Sub tabellogin_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles tabellogin.CellContentClick

    End Sub


    Private Sub clevel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clevel.SelectedIndexChanged

    End Sub
End Class