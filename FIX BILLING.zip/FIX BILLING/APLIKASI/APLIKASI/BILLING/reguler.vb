﻿Imports MySql.Data.MySqlClient
Public Class reguler

    Private Sub reguler_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Koneksi_Ok()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtjam.Text = 0
        txtmenit.Text = 0
        txtdetik.Text = 0
        txtmilidetik.Text = 0
        Timer1.Enabled = True
        Timer1.Start()
        txtdurasi.Enabled = True
        txttagihan.Enabled = True

        If txtnama.Text = "" Then
            MsgBox("Nama Harus Diisi", vbCritical, "Pemberitahuan")
            txtnama.Focus()
        End If

        If txtnama.Text = "" Then
            Timer1.Enabled = False
            txtnama.Focus()
        End If

        If Button2.Enabled Then
            Button1.Enabled = False
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Timer1.Stop()
        Timer1.Enabled = False

        If txtdetik.Text < 15 And txtmenit.Text <= 0 And txtjam.Text <= 0 Then
            txttagihan.Text = 500

        ElseIf (txtdetik.Text >= 15 And txtdetik.Text <= 59 And txtmenit.Text <= 0 And txtjam.Text <= 0) Then
            txttagihan.Text = 1000

        ElseIf (txtmenit.Text >= 1 And txtjam.Text <= 1) Then
            txttagihan.Text = 5000
        End If



        Try
            sql = "INSERT INTO tblreguler VALUES('" & cno.Text & "', '" & txtnama.Text & "', '" & txtdurasi.Text & "', '" & txttagihan.Text & "', '" & DWaktu.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")

        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try

        Button1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        txtmilidetik.Text = txtmilidetik.Text + 1
        If (txtmilidetik.Text >= 10) Then
            txtmilidetik.Text = 0
            txtdetik.Text = txtdetik.Text + 1
            txtdetik.Text = Val(txtdetik.Text + 1)
        End If

        If txtdetik.Text = 60 Then
            txtmenit.Text = Val(txtmenit.Text + 1)
            txtdetik.Text = 0
        End If

        If txtmenit.Text = 60 Then
            txtjam.Text = Val(txtjam.Text + 1)
            txtmenit.Text = 0
        End If


        txtdurasi.Text = txtjam.Text + ":" + txtmenit.Text + ":" + txtdetik.Text + ":" + txtmilidetik.Text
    End Sub

    Private Sub txtdurasi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdurasi.TextChanged

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        cno.Text = ""
        txtnama.Text = ""
        txtdurasi.Text = ""
        txttagihan.Text = ""
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click

    End Sub

    Private Sub DWaktu_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DWaktu.ValueChanged

    End Sub
End Class