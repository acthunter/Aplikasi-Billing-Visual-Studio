﻿Imports MySql.Data.MySqlClient
Public Class data_billing
    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tblreguler", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tblreguler")
        tabelbilling.DataSource = (ds.Tables("tblreguler"))

    End Sub
    Private Sub data_billing_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Koneksi_Ok()
        Call tampil()
    End Sub

    Private Sub tabelbilling_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles tabelbilling.CellContentClick

    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            sql = "INSERT INTO tblreguler VALUES('" & cno.Text & "', '" & txtnama.Text & "', '" & txtdurasi.Text & "', '" & txttagihan.Text & "', '" & DWaktu.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")

        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim hapus As String
        hapus = "delete from tblreguler where no='" & cno.Text & "'"
        cmd = New MySqlCommand(hapus, conn)
        cmd.ExecuteNonQuery()
        MsgBox("DATA SUDAH TERHAPUS", MsgBoxStyle.Information, "INFORMASI")
        cno.Enabled = True
        Call tampil()
    End Sub
End Class