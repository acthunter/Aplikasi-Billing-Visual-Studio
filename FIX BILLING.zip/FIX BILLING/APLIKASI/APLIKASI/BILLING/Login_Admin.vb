﻿Imports MySql.Data.MySqlClient
Public Class Login_Admin

    Private Sub Login_Admin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Koneksi_Ok()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username, password, level As String
        username = vuser.Text
        password = vpas.Text
        level = clevel.SelectedItem
        sql = "select * from tbllogin where username='" + username + "' and password='" + password + "' and level='" + level + "'"
        cmd = New MySqlCommand(sql, conn)
        rd = cmd.ExecuteReader
        If rd.HasRows = True Then
            If level = "admin" Then
                menu_program.DataBillingToolStripMenuItem.Enabled = True
                menu_program.TambahAdminToolStripMenuItem.Enabled = False
                menu_program.PaketRegulerToolStripMenuItem.Enabled = True
                menu_program.LaporanDataBillingToolStripMenuItem.Enabled = False
                menu_program.Show()
                Me.Hide()
            ElseIf level = "owner" Then
                menu_program.DataBillingToolStripMenuItem.Enabled = True
                menu_program.TambahAdminToolStripMenuItem.Enabled = True
                menu_program.PaketRegulerToolStripMenuItem.Enabled = True
                menu_program.LaporanDataBillingToolStripMenuItem.Enabled = True
                menu_program.Show()
                Me.Hide()
            ElseIf level = "personal" Then
                menu_program.DataBillingToolStripMenuItem.Enabled = False
                menu_program.TambahAdminToolStripMenuItem.Enabled = False
                menu_program.PaketRegulerToolStripMenuItem.Enabled = True
                menu_program.LaporanDataBillingToolStripMenuItem.Enabled = False
                menu_program.Show()
                Me.Hide()
            End If
        Else
            MessageBox.Show("Password dan hak akses salah", "Pemberitahuan", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        rd.Close()
        cmd.Dispose()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class